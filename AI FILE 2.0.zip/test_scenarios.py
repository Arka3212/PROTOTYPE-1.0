import json
from decision_engine import evaluate

scenarios = {
    "drone_confirmed_survivor": {
        "system_id": "DRONE_26177",
        "thermal": {"surface_temp_c": 36.4, "ambient_temp_c": 22.0},
        "optical": {"human_silhouette_confidence": 0.81, "gesture_detected": True, "debris_obstruction": True},
        "gps": {"latitude": 26.9124, "longitude": 75.7873, "altitude_m": 42.0},
    },
    "drone_hot_rock_false_positive_guard": {
        "system_id": "DRONE_26177",
        "thermal": {"surface_temp_c": 38.0, "ambient_temp_c": 20.0},
        "optical": {"human_silhouette_confidence": 0.10, "gesture_detected": False, "debris_obstruction": False},
        "gps": {"latitude": 26.91, "longitude": 75.78, "altitude_m": 40.0},
    },
    "drone_no_thermal_match": {
        "system_id": "DRONE_26177",
        "thermal": {"surface_temp_c": 25.0, "ambient_temp_c": 24.0},
        "optical": {"human_silhouette_confidence": 0.95, "gesture_detected": True, "debris_obstruction": False},
        "gps": {"latitude": 26.91, "longitude": 75.78, "altitude_m": 40.0},
    },
    "rover_disease_high_confidence": {
        "system_id": "ROVER_26180",
        "npk": {"nitrogen": 150.0, "phosphorus": 40.0, "potassium": 220.0},
        "leaf_analysis": {"pest_or_disease_confidence": 0.93, "condition": "fungal_blight"},
        "canopy_thermal": {"canopy_temp_c": 29.0, "ambient_temp_c": 27.0},
    },
    "rover_borderline_no_spray": {
        "system_id": "ROVER_26180",
        "npk": {"nitrogen": 150.0, "phosphorus": 40.0, "potassium": 220.0},
        "leaf_analysis": {"pest_or_disease_confidence": 0.60, "condition": "minor_chlorosis"},
        "canopy_thermal": {"canopy_temp_c": 28.0, "ambient_temp_c": 27.0},
    },
    "rover_nutrient_deficit_and_heat_stress": {
        "system_id": "ROVER_26180",
        "npk": {"nitrogen": 80.0, "phosphorus": 40.0, "potassium": 210.0},
        "leaf_analysis": {"pest_or_disease_confidence": 0.05, "condition": "none"},
        "canopy_thermal": {"canopy_temp_c": 33.0, "ambient_temp_c": 28.0},
    },
}

for name, payload in scenarios.items():
    print(f"\n=== {name} ===")
    print(json.dumps(evaluate(payload), indent=2))
