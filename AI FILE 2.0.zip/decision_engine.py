"""
Aegis-Terra Core :: Decision Engine
====================================
Deterministic, rule-based edge-decision logic for two SIH hardware systems:

  - DRONE_26177  : Autonomous Disaster Management Drone
  - ROVER_26180  : Precision Agricultural Assistance Rover

DESIGN NOTE (read this before you demo it to judges):
This module is intentionally RULE-BASED, not a trained neural network. A real
ESP32 cannot run a heavyweight vision model, and a hackathon judge will ask
"where does confidence_score actually come from?" The honest answer for a
36-48 hour build is:

  1. Cheap sensor math (thermal delta, NPK range checks) runs entirely on
     this engine, deterministically, with no ML needed.
  2. "Visual" confidence (human silhouette / pest & disease detection) is
     accepted as an INPUT to this engine -- produced upstream by either:
       a) a TensorFlow-Lite-Micro model flashed to the ESP32-CAM itself, or
       b) a small vision model running on a companion board / phone / laptop
          that the ESP32 talks to over WiFi (this is what most SIH teams
          actually ship, and it's a legitimate architecture -- say so
          explicitly in your PPT).
  3. This engine's job is to FUSE those numbers with deterministic
     thresholds and produce one unambiguous machine command. That fusion
     step is real, testable, and demoable -- which is what you want in
     front of judges.

If you later train a real TFLite classifier, its output confidence just
becomes the `optical_confidence` / `pest_confidence` input below -- nothing
else in this file needs to change.
"""

from __future__ import annotations
from typing import Any, Optional
import math

# ---------------------------------------------------------------------------
# Shared constants (from the hackathon PS constraints)
# ---------------------------------------------------------------------------

# Drone thresholds
HUMAN_TEMP_MIN_C = 34.0
HUMAN_TEMP_MAX_C = 39.5
MIN_THERMAL_CONTRAST_C = 3.0     # surface must stand out from surroundings by this much
SURVIVOR_CONFIDENCE_THRESHOLD = 0.75

# Rover thresholds
NPK_BASELINE = {
    "nitrogen":   (100.0, 200.0),   # mg/kg
    "phosphorus": (30.0, 50.0),
    "potassium":  (150.0, 300.0),
}
PEST_DISEASE_CONFIDENCE_THRESHOLD = 0.75
CANOPY_STRESS_DELTA_C = 2.5        # canopy-vs-ambient delta indicating water stress
SPRAY_MIN_MS = 500
SPRAY_MAX_MS = 2000

SOLENOID_GPIO_PIN = 4  # per schema default; override via payload if your wiring differs


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def _round2(value: float) -> float:
    return round(float(value), 2)


def _npk_status(value: Optional[float], bounds: tuple[float, float]) -> str:
    if value is None:
        return "OPTIMAL"  # no reading -> assume nominal rather than false-alarming
    lo, hi = bounds
    if value < lo:
        return "DEFICIENT"
    if value > hi:
        return "SURPLUS"
    return "OPTIMAL"


def _empty_command_shell(system_id: str) -> dict[str, Any]:
    """Baseline JSON shell matching the required schema exactly."""
    return {
        "system_id": system_id,
        "decision_summary": "",
        "sensor_analysis": {
            "detection_type": "NORMAL",
            "confidence_score": 0.0,
            "thermal_delta_c": 0.0,
            "npk_status": {
                "nitrogen": "OPTIMAL",
                "phosphorus": "OPTIMAL",
                "potassium": "OPTIMAL",
            },
        },
        "hardware_execution": {
            "solenoid_spray": {
                "trigger": False,
                "gpio_pin": SOLENOID_GPIO_PIN,
                "spray_duration_ms": 0,
            },
            "locomotion_command": "FORWARD",
            "speed_or_throttle_pct": 0,
        },
        "rescue_operator_dispatch": {
            "broadcast_alert": False,
            "severity": "NORMAL",
            "gps_coordinates": {"latitude": None, "longitude": None, "altitude_m": None},
            "message": "",
        },
    }


# ---------------------------------------------------------------------------
# DRONE_26177 logic
# ---------------------------------------------------------------------------

def evaluate_drone(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Expected payload shape (extra fields are ignored, missing fields default safely):

    {
      "system_id": "DRONE_26177",
      "thermal": {"surface_temp_c": 36.2, "ambient_temp_c": 24.0},
      "optical": {
          "human_silhouette_confidence": 0.82,   # 0.0-1.0, from onboard/edge vision model
          "gesture_detected": true,
          "debris_obstruction": false
      },
      "gps": {"latitude": 26.9124, "longitude": 75.7873, "altitude_m": 42.0}
    }
    """
    out = _empty_command_shell("DRONE_26177")

    thermal = payload.get("thermal", {}) or {}
    optical = payload.get("optical", {}) or {}
    gps = payload.get("gps", {}) or {}

    surface_temp = thermal.get("surface_temp_c")
    ambient_temp = thermal.get("ambient_temp_c")

    thermal_delta = 0.0
    thermal_match = False
    if surface_temp is not None and ambient_temp is not None:
        thermal_delta = surface_temp - ambient_temp
        in_human_range = HUMAN_TEMP_MIN_C <= surface_temp <= HUMAN_TEMP_MAX_C
        stands_out = abs(thermal_delta) >= MIN_THERMAL_CONTRAST_C
        thermal_match = in_human_range and stands_out

    optical_confidence = float(optical.get("human_silhouette_confidence", 0.0) or 0.0)
    optical_confidence = _clamp(optical_confidence, 0.0, 1.0)
    gesture = bool(optical.get("gesture_detected", False))
    debris = bool(optical.get("debris_obstruction", False))

    # Fusion: thermal gate must pass at all (hard constraint), then blend with optical.
    # A gesture (e.g. waving) is strong corroborating evidence and gets a confidence bump.
    if thermal_match:
        confidence = 0.45 + 0.55 * optical_confidence
    else:
        # No qualifying thermal signature -> optical alone cannot confirm a survivor.
        confidence = 0.25 * optical_confidence

    if gesture and thermal_match:
        confidence = _clamp(confidence + 0.10, 0.0, 1.0)

    confidence = _clamp(confidence, 0.0, 1.0)
    survivor_confirmed = confidence >= SURVIVOR_CONFIDENCE_THRESHOLD

    out["sensor_analysis"]["thermal_delta_c"] = _round2(thermal_delta)
    out["sensor_analysis"]["confidence_score"] = _round2(confidence)

    if survivor_confirmed:
        severity = "CRITICAL" if (debris or gesture) else "MEDIUM"
        out["sensor_analysis"]["detection_type"] = "HUMAN_SURVIVOR"
        out["hardware_execution"]["locomotion_command"] = "HOVER"
        out["hardware_execution"]["speed_or_throttle_pct"] = 0
        out["rescue_operator_dispatch"] = {
            "broadcast_alert": True,
            "severity": severity,
            "gps_coordinates": {
                "latitude": gps.get("latitude"),
                "longitude": gps.get("longitude"),
                "altitude_m": gps.get("altitude_m"),
            },
            "message": (
                f"Survivor signature confirmed (confidence {confidence:.2f}). "
                f"{'Debris obstruction noted. ' if debris else ''}"
                f"{'Gesture/waving detected. ' if gesture else ''}"
                "Hovering and broadcasting position for rescue dispatch."
            ),
        }
        out["decision_summary"] = (
            "HOVER_AND_BROADCAST issued: thermal + optical evidence exceeds survivor "
            "confidence threshold."
        )
    else:
        out["sensor_analysis"]["detection_type"] = "NORMAL"
        out["hardware_execution"]["locomotion_command"] = "FORWARD"
        out["hardware_execution"]["speed_or_throttle_pct"] = 55
        out["decision_summary"] = (
            "No survivor confirmed this frame; continuing search pattern."
        )

    return out


# ---------------------------------------------------------------------------
# ROVER_26180 logic
# ---------------------------------------------------------------------------

def evaluate_rover(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Expected payload shape:

    {
      "system_id": "ROVER_26180",
      "npk": {"nitrogen": 85.0, "phosphorus": 40.0, "potassium": 210.0},
      "leaf_analysis": {
          "pest_or_disease_confidence": 0.88,   # 0.0-1.0, from onboard/edge vision model
          "condition": "fungal_blight"           # free text label, optional
      },
      "canopy_thermal": {"canopy_temp_c": 31.0, "ambient_temp_c": 27.5},
      "gps": {"latitude": 26.9, "longitude": 75.78, "altitude_m": 5.0}
    }
    """
    out = _empty_command_shell("ROVER_26180")

    npk = payload.get("npk", {}) or {}
    leaf = payload.get("leaf_analysis", {}) or {}
    canopy = payload.get("canopy_thermal", {}) or {}

    n_status = _npk_status(npk.get("nitrogen"), NPK_BASELINE["nitrogen"])
    p_status = _npk_status(npk.get("phosphorus"), NPK_BASELINE["phosphorus"])
    k_status = _npk_status(npk.get("potassium"), NPK_BASELINE["potassium"])
    out["sensor_analysis"]["npk_status"] = {
        "nitrogen": n_status,
        "phosphorus": p_status,
        "potassium": k_status,
    }
    nutrient_deficit = any(s == "DEFICIENT" for s in (n_status, p_status, k_status))

    canopy_temp = canopy.get("canopy_temp_c")
    ambient_temp = canopy.get("ambient_temp_c")
    thermal_delta = 0.0
    canopy_stress = False
    if canopy_temp is not None and ambient_temp is not None:
        thermal_delta = canopy_temp - ambient_temp
        canopy_stress = thermal_delta >= CANOPY_STRESS_DELTA_C
    out["sensor_analysis"]["thermal_delta_c"] = _round2(thermal_delta)

    pest_confidence = float(leaf.get("pest_or_disease_confidence", 0.0) or 0.0)
    pest_confidence = _clamp(pest_confidence, 0.0, 1.0)
    condition = leaf.get("condition", "unspecified")

    out["sensor_analysis"]["confidence_score"] = _round2(pest_confidence)

    spray_triggered = pest_confidence >= PEST_DISEASE_CONFIDENCE_THRESHOLD

    if spray_triggered:
        # Scale pulse duration linearly with confidence between MIN and MAX,
        # so a borderline detection sprays conservatively and a high-confidence
        # one gets a fuller dose -- conserves pesticide per PS constraint.
        span = SPRAY_MAX_MS - SPRAY_MIN_MS
        duration = SPRAY_MIN_MS + span * (
            (pest_confidence - PEST_DISEASE_CONFIDENCE_THRESHOLD) / (1.0 - PEST_DISEASE_CONFIDENCE_THRESHOLD)
        )
        duration_ms = int(round(_clamp(duration, SPRAY_MIN_MS, SPRAY_MAX_MS)))

        out["sensor_analysis"]["detection_type"] = "CROP_DISEASE"
        out["hardware_execution"]["solenoid_spray"] = {
            "trigger": True,
            "gpio_pin": SOLENOID_GPIO_PIN,
            "spray_duration_ms": duration_ms,
        }
        out["hardware_execution"]["locomotion_command"] = "HALT"
        out["hardware_execution"]["speed_or_throttle_pct"] = 0
        out["decision_summary"] = (
            f"Pest/disease confidence {pest_confidence:.2f} exceeds threshold "
            f"({condition}); spraying for {duration_ms}ms."
        )
    elif nutrient_deficit:
        out["sensor_analysis"]["detection_type"] = "NUTRIENT_DEFICIT"
        out["hardware_execution"]["locomotion_command"] = "FORWARD"
        out["hardware_execution"]["speed_or_throttle_pct"] = 40
        deficient_list = [k for k, s in out["sensor_analysis"]["npk_status"].items() if s == "DEFICIENT"]
        out["decision_summary"] = (
            f"No spray action needed; soil deficient in {', '.join(deficient_list)} "
            "-- logging for fertigation planning."
        )
    else:
        out["sensor_analysis"]["detection_type"] = "NORMAL"
        out["hardware_execution"]["locomotion_command"] = "FORWARD"
        out["hardware_execution"]["speed_or_throttle_pct"] = 60
        out["decision_summary"] = "Crop and soil metrics nominal; continuing patrol row."

    if canopy_stress:
        out["decision_summary"] += (
            f" Canopy thermal stress detected (Δ{thermal_delta:.1f}°C) -- flag for irrigation review."
        )

    return out


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def evaluate(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Single dispatch entry point. Routes on payload["system_id"].
    Accepts "DRONE_26177" / "ROVER_26180" (case-insensitive), or common aliases.
    """
    system_id = str(payload.get("system_id", "")).strip().upper()

    if "DRONE" in system_id or system_id == "26177":
        return evaluate_drone(payload)
    if "ROVER" in system_id or system_id == "26180":
        return evaluate_rover(payload)

    raise ValueError(
        f"Unrecognized system_id '{payload.get('system_id')}'. "
        "Expected 'DRONE_26177' or 'ROVER_26180'."
    )


if __name__ == "__main__":
    import json
    import sys

    # Allow: python3 decision_engine.py path/to/payload.json
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f:
            data = json.load(f)
        print(json.dumps(evaluate(data), indent=2))
    else:
        print("Usage: python3 decision_engine.py <payload.json>", file=sys.stderr)
        sys.exit(1)
