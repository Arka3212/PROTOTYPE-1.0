"""
Aegis-Terra Core :: HTTP Bridge
================================
Exposes decision_engine.evaluate() as a REST endpoint the ESP32 can POST
telemetry to over WiFi. Uses only the Python standard library (no Flask/
FastAPI required) so it runs anywhere Python 3 does -- a laptop, a Raspberry
Pi acting as a field gateway, or a cloud VM.

ESP32-side usage (Arduino, HTTPClient library):

    HTTPClient http;
    http.begin("http://<this-machine-ip>:8080/telemetry");
    http.addHeader("Content-Type", "application/json");
    int code = http.POST(jsonPayload);
    String response = http.getString();   // parse with ArduinoJson

Endpoints:
    POST /telemetry   -> body: sensor payload JSON, returns: command JSON
    GET  /health      -> returns: {"status": "ok"}

Run:
    python3 server.py [port]        (default port 8080)
"""

from __future__ import annotations
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from decision_engine import evaluate
import vision_analysis


def _enrich_with_vision(payload: dict) -> dict:
    """
    If the payload contains raw image fields, run them through the local
    vision pipeline (vision_analysis.py) and inject the computed confidence
    numbers into the structure decision_engine.evaluate() expects. This is
    what makes the system a real local AI assistant rather than a pass-through:
    the ESP32 can just send raw JPEG frames, and all the inference happens
    here on the laptop, fully offline.

    Recognized optional fields (base64-encoded JPEG/PNG strings):
      - "optical_image_b64"   -> drone human-silhouette detection
      - "leaf_image_b64"      -> rover leaf disease detection
      - "thermal_image_b64"   -> either system's thermal analysis
    """
    system_id = str(payload.get("system_id", "")).upper()

    if "optical_image_b64" in payload:
        result = vision_analysis.detect_human_silhouette(payload["optical_image_b64"])
        optical = payload.setdefault("optical", {})
        optical.setdefault("human_silhouette_confidence", result["confidence"])
        optical.setdefault("gesture_detected", result["gesture_detected"])

    if "leaf_image_b64" in payload:
        result = vision_analysis.analyze_leaf_health(payload["leaf_image_b64"])
        leaf = payload.setdefault("leaf_analysis", {})
        leaf.setdefault("pest_or_disease_confidence", result["confidence"])
        leaf.setdefault("condition", result["condition"])

    if "thermal_image_b64" in payload:
        result = vision_analysis.analyze_thermal_image(payload["thermal_image_b64"])
        if "DRONE" in system_id:
            thermal = payload.setdefault("thermal", {})
            thermal.setdefault("surface_temp_c", result["max_temp_c"])
            thermal.setdefault("ambient_temp_c", result["scene_avg_temp_c"])
        else:
            canopy = payload.setdefault("canopy_thermal", {})
            canopy.setdefault("canopy_temp_c", result["max_temp_c"])
            canopy.setdefault("ambient_temp_c", result["scene_avg_temp_c"])

    return payload


class AegisHandler(BaseHTTPRequestHandler):
    server_version = "AegisTerraCore/1.0"

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self._send_json(200, {"status": "ok"})
        else:
            self._send_json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/telemetry":
            self._send_json(404, {"error": "not found"})
            return

        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b""

        try:
            payload = json.loads(raw or b"{}")
        except json.JSONDecodeError as e:
            self._send_json(400, {"error": f"invalid JSON: {e}"})
            return

        try:
            payload = _enrich_with_vision(payload)
            result = evaluate(payload)
        except ValueError as e:
            self._send_json(422, {"error": str(e)})
            return
        except Exception as e:  # noqa: BLE001 -- keep the field device fed a clean error
            self._send_json(500, {"error": f"internal error: {e}"})
            return

        detection = result["sensor_analysis"]["detection_type"]
        conf = result["sensor_analysis"]["confidence_score"]
        print(f"[decision] {result['system_id']}: {detection} (confidence={conf})")

        self._send_json(200, result)

    def log_message(self, fmt, *args):  # quieter default logging
        sys.stderr.write("[aegis-terra-core] " + (fmt % args) + "\n")


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    server = ThreadingHTTPServer(("0.0.0.0", port), AegisHandler)
    print(f"Aegis-Terra Core listening on http://0.0.0.0:{port}  (POST /telemetry, GET /health)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.shutdown()


if __name__ == "__main__":
    main()
