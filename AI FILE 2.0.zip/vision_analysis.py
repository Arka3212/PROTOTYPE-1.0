"""
Aegis-Terra Core :: Vision Analysis (Tier A -- laptop-side, fully offline AI)
==============================================================================
This is the actual "AI" layer. It runs entirely on your laptop (or a Raspberry
Pi), needs zero internet access at inference time, and produces the
confidence numbers that decision_engine.py fuses into a command.

Three capabilities, all real and tested, none requiring you to train
anything first:

  1. detect_human_silhouette() -- uses OpenCV's built-in HOG+SVM pedestrian
     detector. This is a real pretrained classical ML model that ships
     inside OpenCV itself. Zero setup, zero training data needed.

  2. analyze_leaf_health()    -- HSV color-segmentation heuristic. Not deep
     learning, but a real, deterministic, widely-used plant-pathology
     technique: healthy leaf tissue is green; disease/necrosis/chlorosis
     shifts pixels toward yellow/brown. Returns a confidence + area ratio.

  3. analyze_thermal_image()  -- decodes a false-color or grayscale thermal
     snapshot into estimated surface temperatures using a calibration
     mapping, so the drone doesn't need a human to type in a temperature by
     hand -- it comes straight off the camera frame.

UPGRADE PATH: once you've collected labeled photos from your own hardware
(a folder of "survivor" / "no_survivor" crops, or "diseased" / "healthy"
leaf crops), run train_vision_model.py to train a real scikit-learn
classifier (HOG + color-histogram features -> RandomForest) that will
outperform these heuristics. If a trained model file is present, the
functions below use it automatically; otherwise they fall back to the
heuristics implemented here. Either way, nothing here ever calls the
internet or a paid API -- it's real local inference.
"""

from __future__ import annotations
import base64
import io
import os
from typing import Optional

import cv2
import numpy as np

_MODEL_DIR = os.path.join(os.path.dirname(__file__), "trained_models")
_HUMAN_MODEL_PATH = os.path.join(_MODEL_DIR, "human_classifier.joblib")
_LEAF_MODEL_PATH = os.path.join(_MODEL_DIR, "leaf_classifier.joblib")

# Lazily-loaded singletons so we don't reconstruct detectors on every request.
_hog_detector = None
_human_clf = None
_leaf_clf = None


def _get_hog_detector():
    global _hog_detector
    if _hog_detector is None:
        hog = cv2.HOGDescriptor()
        hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        _hog_detector = hog
    return _hog_detector


def _try_load_trained_model(path: str):
    """Returns a loaded joblib model if it exists, else None. Never raises."""
    if not os.path.exists(path):
        return None
    try:
        import joblib  # local import: only needed if a trained model exists
        return joblib.load(path)
    except Exception:
        return None


def decode_image(image_b64: str) -> np.ndarray:
    """Decode a base64-encoded JPEG/PNG (as the ESP32-CAM would send) into a BGR numpy array."""
    raw = base64.b64decode(image_b64)
    arr = np.frombuffer(raw, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image -- check it is valid JPEG/PNG bytes, base64-encoded.")
    return img


# ---------------------------------------------------------------------------
# 1. Human silhouette detection (for DRONE_26177)
# ---------------------------------------------------------------------------

def _extract_clf_features(img: np.ndarray) -> np.ndarray:
    """Must match train_vision_model.py's _extract_features exactly."""
    resized = cv2.resize(img, (128, 128))
    hog = cv2.HOGDescriptor(_winSize=(128, 128), _blockSize=(32, 32),
                             _blockStride=(16, 16), _cellSize=(16, 16), _nbins=9)
    hog_feat = hog.compute(resized).flatten()
    hist_feat = []
    for ch in range(3):
        hist = cv2.calcHist([resized], [ch], None, [32], [0, 256])
        hist_feat.append(cv2.normalize(hist, hist).flatten())
    return np.concatenate([hog_feat] + hist_feat)


def detect_human_silhouette(image_b64: str) -> dict:
    """
    Returns:
        {
          "confidence": 0.0-1.0,
          "detections": [{"x":.., "y":.., "w":.., "h":.., "weight":..}, ...],
          "gesture_detected": bool,   # heuristic: a tall, narrow, high-confidence box
          "source": "trained_model" | "hog_heuristic"
        }

    If trained_models/human_classifier.joblib exists (see train_vision_model.py),
    it is used as the primary confidence signal -- it will have learned your
    specific deployment conditions and outperforms the generic HOG heuristic.
    The HOG detector's bounding boxes are still returned either way, since
    they're useful for logging/visualization regardless of which model scores it.
    """
    img = decode_image(image_b64)

    global _human_clf
    if _human_clf is None:
        _human_clf = _try_load_trained_model(_HUMAN_MODEL_PATH)

    hog = _get_hog_detector()
    # detectMultiScale returns bounding boxes + a "weight" (higher = more confident)
    boxes, weights = hog.detectMultiScale(
        img, winStride=(8, 8), padding=(8, 8), scale=1.05
    )

    detections = []
    max_weight = 0.0
    for (x, y, w, h), weight in zip(boxes, weights):
        w_scalar = float(weight[0]) if hasattr(weight, "__len__") else float(weight)
        detections.append({"x": int(x), "y": int(y), "w": int(w), "h": int(h), "weight": w_scalar})
        max_weight = max(max_weight, w_scalar)

    source = "hog_heuristic"
    if _human_clf is not None:
        try:
            feat = _extract_clf_features(img).reshape(1, -1)
            proba = _human_clf["model"].predict_proba(feat)[0]
            # proba[1] = P(positive class), by convention from train_vision_model.py
            confidence = float(np.clip(proba[1], 0.0, 1.0))
            source = "trained_model"
        except Exception:
            confidence = 0.0 if not detections else None  # fall through below
    if source == "hog_heuristic":
        # HOG weights are unbounded log-odds-ish scores; typical confident detections
        # sit around 0.5-2.0+. Squash to 0-1 with a logistic so it composes cleanly
        # with the rest of the fusion logic in decision_engine.py.
        confidence = 1.0 / (1.0 + np.exp(-2.0 * (max_weight - 0.5))) if detections else 0.0
        confidence = float(np.clip(confidence, 0.0, 1.0))

    # crude "gesture" heuristic: a person box that's unusually wide relative to height
    # often indicates raised/spread arms rather than a standing silhouette.
    gesture_detected = any((d["w"] / max(d["h"], 1)) > 0.65 for d in detections)

    return {
        "confidence": round(confidence, 3),
        "detections": detections,
        "gesture_detected": gesture_detected,
        "source": source,
    }


# ---------------------------------------------------------------------------
# 2. Leaf health / disease heuristic (for ROVER_26180)
# ---------------------------------------------------------------------------

def analyze_leaf_health(image_b64: str) -> dict:
    """
    HSV-based heuristic: segments the leaf into healthy-green vs
    diseased (yellow/brown/necrotic) pixel ranges and returns the
    diseased-area ratio as a confidence score.

    Returns:
        {"confidence": 0.0-1.0, "diseased_area_pct": 0.0-100.0, "condition": str, "source": str}

    Uses trained_models/leaf_classifier.joblib if present (see
    train_vision_model.py); falls back to the HSV heuristic otherwise.
    """
    img = decode_image(image_b64)

    global _leaf_clf
    if _leaf_clf is None:
        _leaf_clf = _try_load_trained_model(_LEAF_MODEL_PATH)

    if _leaf_clf is not None:
        try:
            feat = _extract_clf_features(img).reshape(1, -1)
            proba = _leaf_clf["model"].predict_proba(feat)[0]
            confidence = float(np.clip(proba[1], 0.0, 1.0))
            condition = "diseased" if confidence >= 0.5 else "healthy"
            return {"confidence": round(confidence, 3), "diseased_area_pct": None,
                    "condition": condition, "source": "trained_model"}
        except Exception:
            pass  # fall through to heuristic below

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    # Healthy green leaf tissue
    green_lo, green_hi = (35, 40, 40), (85, 255, 255)
    green_mask = cv2.inRange(hsv, green_lo, green_hi)

    # Yellow/chlorotic tissue
    yellow_lo, yellow_hi = (20, 40, 40), (34, 255, 255)
    yellow_mask = cv2.inRange(hsv, yellow_lo, yellow_hi)

    # Brown/necrotic/blighted tissue (low saturation browns + dark spots)
    brown_lo, brown_hi = (5, 40, 20), (19, 255, 200)
    brown_mask = cv2.inRange(hsv, brown_lo, brown_hi)

    leaf_mask = cv2.bitwise_or(green_mask, cv2.bitwise_or(yellow_mask, brown_mask))
    leaf_pixels = int(np.count_nonzero(leaf_mask))
    if leaf_pixels == 0:
        return {"confidence": 0.0, "diseased_area_pct": 0.0, "condition": "no_leaf_detected"}

    diseased_pixels = int(np.count_nonzero(yellow_mask) + np.count_nonzero(brown_mask))
    diseased_pct = 100.0 * diseased_pixels / leaf_pixels

    # Map area percentage to a confidence score. Even a small necrotic/blight
    # patch (>15% of leaf area) is agronomically significant, so the curve
    # is front-loaded rather than linear to 100%.
    confidence = float(np.clip(diseased_pct / 40.0, 0.0, 1.0))

    if diseased_pct < 5:
        condition = "healthy"
    elif np.count_nonzero(brown_mask) > np.count_nonzero(yellow_mask):
        condition = "necrotic_or_blight_spotting"
    else:
        condition = "chlorosis"

    return {
        "confidence": round(confidence, 3),
        "diseased_area_pct": round(diseased_pct, 1),
        "condition": condition,
        "source": "hsv_heuristic",
    }


# ---------------------------------------------------------------------------
# 3. Thermal image decoding (for both systems)
# ---------------------------------------------------------------------------

def analyze_thermal_image(
    image_b64: str,
    temp_min_c: float = 15.0,
    temp_max_c: float = 45.0,
) -> dict:
    """
    Decodes a thermal camera snapshot into an estimated max surface
    temperature and scene-average (ambient proxy) temperature.

    Assumes the thermal camera outputs either:
      (a) a raw grayscale image where pixel intensity 0-255 maps linearly
          to [temp_min_c, temp_max_c] (true for most MLX90640/AMG8833
          false-color-disabled output), or
      (b) a false-color image (e.g. iron palette) -- in which case pass
          the raw grayscale sensor buffer instead for accurate results.
          False-color JPEGs are fine for a human to look at but lossy for
          quantitative temperature extraction.

    Calibrate temp_min_c / temp_max_c to your specific sensor's datasheet
    range before trusting absolute values in a real deployment.

    Returns:
        {"max_temp_c": .., "scene_avg_temp_c": .., "hotspot_delta_c": ..}
    """
    img = decode_image(image_b64)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img

    normalized = gray.astype(np.float32) / 255.0
    temp_map = temp_min_c + normalized * (temp_max_c - temp_min_c)

    max_temp = float(np.max(temp_map))
    avg_temp = float(np.mean(temp_map))
    hotspot_delta = max_temp - avg_temp

    return {
        "max_temp_c": round(max_temp, 2),
        "scene_avg_temp_c": round(avg_temp, 2),
        "hotspot_delta_c": round(hotspot_delta, 2),
    }


if __name__ == "__main__":
    # Self-test with a synthetic image so this file can be verified without
    # any real camera hardware attached. Real accuracy validation requires
    # actual photos from your ESP32-CAM / thermal module.
    print("Running self-test with synthetic images (no real camera needed)...")

    # Synthetic leaf: green square with a brown blight patch
    leaf = np.zeros((200, 200, 3), dtype=np.uint8)
    leaf[:, :] = (60, 140, 60)          # BGR green-ish
    leaf[120:180, 120:180] = (30, 70, 110)  # BGR brown patch
    ok, buf = cv2.imencode(".jpg", leaf)
    leaf_b64 = base64.b64encode(buf).decode()
    print("Leaf analysis:", analyze_leaf_health(leaf_b64))

    # Synthetic thermal frame: gradient with a hot spot
    thermal = np.full((100, 100), 60, dtype=np.uint8)  # cool background
    thermal[40:60, 40:60] = 210  # hot patch
    ok, buf = cv2.imencode(".png", thermal)
    thermal_b64 = base64.b64encode(buf).decode()
    print("Thermal analysis:", analyze_thermal_image(thermal_b64))

    # Synthetic "person" frame -- HOG needs real photographic humans to fire
    # meaningfully; this just proves the pipeline runs without error.
    blank_scene = np.random.randint(0, 255, (240, 320, 3), dtype=np.uint8)
    ok, buf = cv2.imencode(".jpg", blank_scene)
    scene_b64 = base64.b64encode(buf).decode()
    print("Human detection (synthetic noise, expect ~0 confidence):",
          detect_human_silhouette(scene_b64))

    print("\nSelf-test complete. For real accuracy numbers, run this against "
          "actual ESP32-CAM photos.")
