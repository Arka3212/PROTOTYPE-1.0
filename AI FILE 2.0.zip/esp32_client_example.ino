/*
  Aegis-Terra Core :: ESP32 Client Example
  =========================================
  Drop-in pattern for either PS ID 26177 (Drone) or PS ID 26180 (Rover).
  Reads local sensors, builds the JSON payload, POSTs it to the Aegis-Terra
  Core HTTP bridge (server.py), and parses the returned command to drive
  actuators.

  Libraries needed (Arduino Library Manager):
    - WiFi.h            (bundled with ESP32 board package)
    - HTTPClient.h       (bundled with ESP32 board package)
    - ArduinoJson         (by Benoit Blanchon)

  This is a template, not a finished sketch: swap in your real sensor read
  functions where marked TODO.
*/

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_URL    = "http://192.168.1.50:8080/telemetry"; // Aegis-Terra Core host:port

// Set to true on the drone build, false on the rover build.
const bool IS_DRONE = true;

const int SOLENOID_PIN = 4;   // rover only
const int MOTOR_PIN    = 5;   // shared: locomotion / propeller enable

void setup() {
  Serial.begin(115200);
  pinMode(SOLENOID_PIN, OUTPUT);
  pinMode(MOTOR_PIN, OUTPUT);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected: " + WiFi.localIP().toString());
}

void loop() {
  StaticJsonDocument<512> payload;

  if (IS_DRONE) {
    payload["system_id"] = "DRONE_26177";

    JsonObject thermal = payload.createNestedObject("thermal");
    thermal["surface_temp_c"] = readThermalSurfaceTemp();   // TODO: wire to MLX90640/AMG8833 etc.
    thermal["ambient_temp_c"] = readAmbientTemp();           // TODO

    JsonObject optical = payload.createNestedObject("optical");
    optical["human_silhouette_confidence"] = runOnboardVisionModel(); // TODO: TFLite-Micro inference
    optical["gesture_detected"] = false;      // TODO: derive from pose/motion heuristic if available
    optical["debris_obstruction"] = false;    // TODO

    JsonObject gps = payload.createNestedObject("gps");
    gps["latitude"] = readGpsLat();    // TODO: NEO-6M or similar
    gps["longitude"] = readGpsLon();   // TODO
    gps["altitude_m"] = readGpsAlt();  // TODO

  } else {
    payload["system_id"] = "ROVER_26180";

    JsonObject npk = payload.createNestedObject("npk");
    npk["nitrogen"] = readModbusNPK("N");     // TODO: RS485 Modbus register read
    npk["phosphorus"] = readModbusNPK("P");   // TODO
    npk["potassium"] = readModbusNPK("K");    // TODO

    JsonObject leaf = payload.createNestedObject("leaf_analysis");
    leaf["pest_or_disease_confidence"] = runOnboardVisionModel(); // TODO: TFLite-Micro inference
    leaf["condition"] = "unspecified";                              // TODO: class label from model

    JsonObject canopy = payload.createNestedObject("canopy_thermal");
    canopy["canopy_temp_c"] = readCanopyTemp();   // TODO
    canopy["ambient_temp_c"] = readAmbientTemp(); // TODO
  }

  String jsonStr;
  serializeJson(payload, jsonStr);

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(SERVER_URL);
    http.addHeader("Content-Type", "application/json");
    int httpCode = http.POST(jsonStr);

    if (httpCode == 200) {
      String response = http.getString();
      StaticJsonDocument<1024> cmd;
      deserializeJson(cmd, response);
      executeCommand(cmd);
    } else {
      Serial.println("Request failed, code: " + String(httpCode));
    }
    http.end();
  }

  delay(2000); // telemetry cadence -- tune per your PS demo needs
}

void executeCommand(JsonDocument& cmd) {
  const char* locomotion = cmd["hardware_execution"]["locomotion_command"];
  int throttle = cmd["hardware_execution"]["speed_or_throttle_pct"];

  Serial.printf("Locomotion: %s @ %d%%\n", locomotion, throttle);
  analogWrite(MOTOR_PIN, map(throttle, 0, 100, 0, 255));

  if (!IS_DRONE) {
    bool spray = cmd["hardware_execution"]["solenoid_spray"]["trigger"];
    int durationMs = cmd["hardware_execution"]["solenoid_spray"]["spray_duration_ms"];
    if (spray) {
      Serial.printf("SPRAY: %d ms\n", durationMs);
      digitalWrite(SOLENOID_PIN, HIGH);
      delay(durationMs);
      digitalWrite(SOLENOID_PIN, LOW);
    }
  } else {
    bool broadcast = cmd["rescue_operator_dispatch"]["broadcast_alert"];
    if (broadcast) {
      const char* severity = cmd["rescue_operator_dispatch"]["severity"];
      Serial.printf("ALERT [%s]: %s\n", severity,
                    (const char*)cmd["rescue_operator_dispatch"]["message"]);
      // TODO: push to LoRa/telemetry radio for ground-station display
    }
  }
}

// ---- Sensor stubs: replace with real driver calls ----
float readThermalSurfaceTemp() { return 36.0; }
float readAmbientTemp()        { return 24.0; }
float runOnboardVisionModel()  { return 0.0; }
float readGpsLat()             { return 0.0; }
float readGpsLon()             { return 0.0; }
float readGpsAlt()             { return 0.0; }
float readModbusNPK(const char* which) { return 0.0; }
float readCanopyTemp()         { return 0.0; }
