# Stretch Goal: ESP32-Standalone AI (No Laptop at Runtime)

Everything in this repo so far (Tier A) runs the AI on your laptop and talks
to the ESP32 over WiFi. That's the right choice for the demo and for most
SIH judging — it's real, it's testable, and it works today.

This document is the honest roadmap for Tier B: flashing the AI itself onto
the ESP32 so it can make decisions with zero laptop/server present. Be
upfront with judges that this is a genuinely harder embedded-ML problem —
claiming it's "done" without actually doing it will fall apart under a
follow-up question, but describing this roadmap accurately and showing
Tier A working live is a strong submission on its own.

## Why this can't just be copy-pasted from Tier A

- `scikit-learn`, `OpenCV`, and Python don't run on a microcontroller — the
  ESP32 has no OS, ~320KB-520KB of RAM, and a few MB of flash. Tier A's
  models are built for a full OS and can't be flashed directly.
- The real path onto bare metal is **TensorFlow Lite for Microcontrollers
  (TFLM)**: a C++ inference runtime a few hundred KB in size, running a
  quantized (int8) neural network a few hundred KB in size.
- Training that network requires TensorFlow/Keras (needs internet + ideally
  a GPU) on a separate development machine — this sandboxed environment
  doesn't have internet access or TensorFlow installed, which is why this is
  a roadmap for you to run on your own laptop, not something built inside
  this conversation.

## The actual steps (do these on your own machine, with internet)

### 1. Collect and label a dataset from your real hardware
Use your ESP32-CAM (or phone camera at the same resolution/distance you'll
deploy at) to capture 150-300+ images per class:
- Drone: `survivor` / `no_survivor` crops (varied poses, distances, lighting)
- Rover: `diseased_leaf` / `healthy_leaf` crops

More, more-varied data matters far more than a fancier model architecture.

### 2. Train a small CNN with TensorFlow/Keras
```python
import tensorflow as tf

model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(96, 96, 1)),   # grayscale, small = fits ESP32
    tf.keras.layers.Conv2D(8, 3, activation="relu"),
    tf.keras.layers.MaxPooling2D(),
    tf.keras.layers.Conv2D(16, 3, activation="relu"),
    tf.keras.layers.MaxPooling2D(),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(16, activation="relu"),
    tf.keras.layers.Dense(1, activation="sigmoid"),
])
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
model.fit(train_ds, validation_data=val_ds, epochs=20)
```
Keep the input small (96x96 or even 48x48 grayscale) — every pixel costs
RAM at inference time on the ESP32.

### 3. Quantize and convert to TFLite (int8)
```python
converter = tf.lite.TFLiteConverter.from_keras_model(model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]
converter.representative_dataset = representative_data_gen  # a generator over sample inputs
converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
converter.inference_input_type = tf.int8
converter.inference_output_type = tf.int8
tflite_model = converter.convert()
with open("model.tflite", "wb") as f:
    f.write(tflite_model)
```
Check the resulting file size — aim for well under 100-200KB for comfortable
headroom on a standard ESP32 (more on an ESP32-S3 with PSRAM).

### 4. Convert to a C array and flash it
```bash
xxd -i model.tflite > model_data.cc
```
Include `model_data.cc` in your Arduino/ESP-IDF project alongside the
[TFLite Micro Arduino library](https://github.com/tensorflow/tflite-micro-arduino-examples).
The library's `person_detection` example is the closest official template to
your drone use case and is a good starting point to adapt.

### 5. Replace the stub in `esp32_client_example.ino`
The `runOnboardVisionModel()` stub in this repo's `.ino` file is exactly
where the TFLM inference call goes once you've done steps 1-4. At that
point the ESP32 no longer needs `server.py` running at all for the vision
step — though you may still want the laptop bridge for GPS-alert logging
and a human-facing dashboard.

## Realistic scope

This is genuinely a multi-day task even for someone comfortable with
embedded ML — dataset collection alone often takes longer than the model
work. For a hackathon, a strong, honest submission is: Tier A fully working
and demoed live, plus this document as evidence you've scoped Tier B
correctly and know exactly what's left. Judges generally respond better to
an accurate "here's what's done and here's the precise next step" than to
an overclaimed "fully autonomous on-device AI" that can't survive a
follow-up question about model size or latency.
