"""
Aegis-Terra Core :: Local Assistant Launcher
==============================================
One command to bring up the whole system on your laptop:

    python3 local_assistant.py [port]

This starts the HTTP bridge (server.py), which already has the vision
pipeline (vision_analysis.py) and decision engine (decision_engine.py)
wired in. It also prints your laptop's LAN IP on startup so you can paste
it straight into esp32_client_example.ino's SERVER_URL -- no hunting
through ipconfig/ifconfig output during a live demo.

Everything runs locally. No internet connection is required at runtime;
the only thing that ever leaves your laptop is whatever your own ESP32
units send to the ports you configure on your own LAN.
"""

from __future__ import annotations
import socket
import sys

import server  # reuses AegisHandler, _enrich_with_vision, decision_engine, vision_analysis


def _get_lan_ip() -> str:
    """Best-effort local LAN IP discovery (no external network call)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Doesn't actually send packets -- just asks the OS which interface
        # it would use to reach this address, to discover our own LAN IP.
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    lan_ip = _get_lan_ip()

    print("=" * 60)
    print(" AEGIS-TERRA CORE -- Local Assistant")
    print("=" * 60)
    print(f" Listening on : http://0.0.0.0:{port}")
    print(f" LAN address  : http://{lan_ip}:{port}   <-- put this in your ESP32 sketch")
    print(f" Health check : http://{lan_ip}:{port}/health")
    print(" Endpoints    : POST /telemetry")
    print("-" * 60)
    print(" Vision pipeline: OpenCV HOG (human) + HSV heuristic (leaf) active.")
    import os
    for name, path in [
        ("human_classifier", "trained_models/human_classifier.joblib"),
        ("leaf_classifier", "trained_models/leaf_classifier.joblib"),
    ]:
        status = "TRAINED MODEL LOADED" if os.path.exists(path) else "using heuristic fallback"
        print(f"   - {name}: {status}")
    print("-" * 60)
    print(" Live decisions will be logged below as telemetry arrives.")
    print(" Press Ctrl+C to stop.")
    print("=" * 60)

    server.main.__globals__["sys"].argv = ["server.py", str(port)]
    server.main()


if __name__ == "__main__":
    main()
