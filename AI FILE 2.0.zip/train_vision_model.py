"""
Aegis-Terra Core :: Train a Local Vision Model
================================================
Trains a scikit-learn classifier (HOG + color-histogram features ->
RandomForest) on labeled images YOU collect from your own ESP32-CAM or phone.
Runs entirely offline, in a few seconds to minutes depending on dataset size
-- no GPU, no internet, no TensorFlow needed.

This will noticeably outperform the HSV/HOG heuristics in vision_analysis.py
once you have even 30-50 labeled images per class, because it learns the
actual visual conditions of YOUR crop / YOUR test environment rather than
relying on generic thresholds.

USAGE
-----
1. Collect images and sort them into folders:

    training_data/
      human/            <- crops or full frames containing a person
      no_human/         <- frames with no person
    OR
    training_data/
      diseased_leaf/
      healthy_leaf/

2. Run:
    python3 train_vision_model.py --task human --data-dir training_data
    python3 train_vision_model.py --task leaf  --data-dir training_data

3. The trained model is saved to trained_models/human_classifier.joblib or
   trained_models/leaf_classifier.joblib. vision_analysis.py automatically
   picks it up on the next server restart -- no code changes needed.

Folder names for --task human: human/, no_human/
Folder names for --task leaf:  diseased_leaf/, healthy_leaf/
"""

from __future__ import annotations
import argparse
import os
import sys

import cv2
import numpy as np


def _extract_features(img: np.ndarray) -> np.ndarray:
    """HOG descriptor + 3-channel color histogram, concatenated. Fixed-size,
    resolution-independent (image is resized before feature extraction)."""
    resized = cv2.resize(img, (128, 128))

    hog = cv2.HOGDescriptor(_winSize=(128, 128), _blockSize=(32, 32),
                             _blockStride=(16, 16), _cellSize=(16, 16), _nbins=9)
    hog_feat = hog.compute(resized).flatten()

    hist_feat = []
    for ch in range(3):
        hist = cv2.calcHist([resized], [ch], None, [32], [0, 256])
        hist_feat.append(cv2.normalize(hist, hist).flatten())
    hist_feat = np.concatenate(hist_feat)

    return np.concatenate([hog_feat, hist_feat])


def _load_dataset(data_dir: str, positive_dir: str, negative_dir: str):
    X, y = [], []
    for label, folder in [(1, positive_dir), (0, negative_dir)]:
        folder_path = os.path.join(data_dir, folder)
        if not os.path.isdir(folder_path):
            print(f"ERROR: expected folder not found: {folder_path}", file=sys.stderr)
            sys.exit(1)
        files = [f for f in os.listdir(folder_path)
                  if f.lower().endswith((".jpg", ".jpeg", ".png"))]
        if not files:
            print(f"WARNING: no images found in {folder_path}", file=sys.stderr)
        for fname in files:
            img = cv2.imread(os.path.join(folder_path, fname))
            if img is None:
                continue
            X.append(_extract_features(img))
            y.append(label)
    return np.array(X), np.array(y)


def main():
    parser = argparse.ArgumentParser(description="Train a local vision classifier for Aegis-Terra Core")
    parser.add_argument("--task", choices=["human", "leaf"], required=True)
    parser.add_argument("--data-dir", required=True, help="Root folder containing the two labeled subfolders")
    parser.add_argument("--test-split", type=float, default=0.2)
    args = parser.parse_args()

    if args.task == "human":
        positive_dir, negative_dir = "human", "no_human"
        out_name = "human_classifier.joblib"
    else:
        positive_dir, negative_dir = "diseased_leaf", "healthy_leaf"
        out_name = "leaf_classifier.joblib"

    print(f"Loading dataset from {args.data_dir} ...")
    X, y = _load_dataset(args.data_dir, positive_dir, negative_dir)
    if len(X) < 10:
        print(f"ERROR: only found {len(X)} labeled images total. Collect at least "
              "~20-30 per class for a meaningful model.", file=sys.stderr)
        sys.exit(1)
    print(f"Loaded {len(X)} images ({int(y.sum())} positive, {len(y) - int(y.sum())} negative).")

    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import classification_report
    import joblib

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_split, random_state=42, stratify=y if len(set(y)) > 1 else None
    )

    clf = RandomForestClassifier(n_estimators=200, max_depth=12, random_state=42, n_jobs=-1)
    clf.fit(X_train, y_train)

    if len(X_test) > 0:
        preds = clf.predict(X_test)
        print("\nHold-out evaluation:")
        print(classification_report(y_test, preds, target_names=[f"not_{positive_dir}", positive_dir]))

    out_dir = os.path.join(os.path.dirname(__file__), "trained_models")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, out_name)
    joblib.dump({"model": clf, "feature_fn": "hog_color_hist_v1"}, out_path)
    print(f"\nSaved trained model to {out_path}")
    print("Restart server.py to pick it up automatically.")


if __name__ == "__main__":
    main()
